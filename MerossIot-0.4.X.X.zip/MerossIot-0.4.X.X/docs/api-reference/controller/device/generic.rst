GenericSubDevice
----------------

.. autoclass:: meross_iot.controller.device.GenericSubDevice
   :members:
