Ms100Sensor
-----------

.. autoclass:: meross_iot.controller.known.subdevice.Ms100Sensor
   :members:
