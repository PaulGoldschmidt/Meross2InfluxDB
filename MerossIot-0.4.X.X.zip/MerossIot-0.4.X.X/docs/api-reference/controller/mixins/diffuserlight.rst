DiffuserLightMixin
------------

.. autoclass:: meross_iot.controller.mixins.diffuser_light.DiffuserLightMixin
   :members:
