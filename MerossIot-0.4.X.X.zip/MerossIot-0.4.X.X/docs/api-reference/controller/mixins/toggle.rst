ToggleXMixin
------------

.. autoclass:: meross_iot.controller.mixins.toggle.ToggleXMixin
   :members:

ToggleMixin
------------

.. autoclass:: meross_iot.controller.mixins.toggle.ToggleMixin
   :members:
