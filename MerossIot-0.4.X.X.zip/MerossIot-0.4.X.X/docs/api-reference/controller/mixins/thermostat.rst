ThermostatMixin
------------

.. autoclass:: meross_iot.controller.mixins.thermostat.ThermostatModeMixin
   :members:

.. autoclass:: meross_iot.controller.mixins.thermostat.ThermostatState
   :members:
