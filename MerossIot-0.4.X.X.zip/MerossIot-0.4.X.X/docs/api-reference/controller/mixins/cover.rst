GarageOpenerMixin
-----------------

.. autoclass:: meross_iot.controller.mixins.garage.GarageOpenerMixin
   :members:
