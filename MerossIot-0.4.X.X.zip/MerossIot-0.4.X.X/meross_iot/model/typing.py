from typing import Tuple

RgbTuple = Tuple[int, int, int]
